﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.DataAcsess
{
    
}
public class Item : IEquatable<Item>
{
    public string _msg;
    public int Id;
    public string Name;
    public int number;
    public string Color;



    public Item(string name, int ID = 0, string MSG = "Chad", int Number = 5, string color = "Yes")
    {
        this._msg = MSG;
        this.Id = ID;
        this.Name = name;
        this.number = Number;
        this.Color = color;

    }
    public bool Equals(Item other)
    {
        if (other == null) return false;
        return (this._msg.Equals(other._msg));
    }
}
