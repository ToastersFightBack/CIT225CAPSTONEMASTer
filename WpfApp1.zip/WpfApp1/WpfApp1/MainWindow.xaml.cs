﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using WpfApp1.DataAcsess;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
   
    public partial class MainWindow : INotifyPropertyChanged
    {
        public MainWindow()
        {
            DataContext = this;
            InitializeComponent();
        }
        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            
            String BoundNumber = File.ReadAllText("data.json");
            List<Item> myList = JsonConvert.DeserializeObject<List<Item>>(BoundNumber);
            if (myList == null)
                myList = new List<Item>();
            foreach (Item item in myList)
            {
                ListBox1.Items.Add(" Name: " + item.Name + " ID: " + item.Id + " MSG: " + item._msg + " Number: " + item.number +   " Color: " + item.Color);
            }

        }
        private void Update_Click(object sender, RoutedEventArgs e)
        {
            int ID;
            string MSG;
            string Name;
            int Number;
            string color;

            String BoundNumber = File.ReadAllText("data.json");
            List<Item> myList = JsonConvert.DeserializeObject<List<Item>>(BoundNumber);
            if (myList == null)
                myList = new List<Item>();
            ListBox1.Items.Remove(ListBox1.SelectedItem);
            try
            {
                bool isNumber = int.TryParse(IDText.Text, out ID);
            }
            catch (Exception)
            {
                MessageBox.Show("Enter A number for ID");
                throw;
            }
            try
            {
                bool isNumber2 = int.TryParse(NumberText.Text, out Number);
            }
            catch (Exception)
            {
                MessageBox.Show("Enter A number For Number");
                throw;
            }
            
            MSG = MSGText.Text;
            Name = NameText.Text;
            color = ColorText.Text;
            myList.Add(new Item(MSG, ID, Name, Number, color));
            ListBox1.Items.Add(" Name: " + Name + " ID: " + ID + " MSG " + MSG + " Number " + Number + " Color " + color);
            string data = JsonConvert.SerializeObject(myList);
            File.WriteAllText("data.json", data);
        }
        private void Add_Click(object sender, RoutedEventArgs e)
        {

            int ID;
            string MSG;
            string Name;
            int Number;
            string color;
            String BoundNumber = File.ReadAllText("data.json");
            List<Item> myList = JsonConvert.DeserializeObject<List<Item>>(BoundNumber);
            if (myList == null)
                myList = new List<Item>();
            try
            {
                bool isNumber = int.TryParse(IDText.Text, out ID);
            }
            catch (Exception)
            {
                MessageBox.Show("Enter A number for ID");
                throw;
            }
            try
            {
                bool isNumber2 = int.TryParse(NumberText.Text, out Number);
            }
            catch (Exception)
            {
                MessageBox.Show("Enter A number For Number");
                throw;
            }
            MSG = MSGText.Text;
            Name = NameText.Text;
            color = ColorText.Text;
            myList.Add(new Item(MSG, ID, Name, Number, color));
            ListBox1.Items.Add(" Name: " + Name + " ID: " + ID + " MSG " + MSG + " Number " + Number + " Color " + color);
            string data = JsonConvert.SerializeObject(myList);
            File.WriteAllText("data.json", data);
        }
        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            String BoundNumber = File.ReadAllText("data.json");
            List<Item> myList = JsonConvert.DeserializeObject<List<Item>>(BoundNumber);
            ListBox1.Items.Remove(ListBox1.SelectedItem);

            myList.Clear();
        }


        private string _boundNumber;
        public string BoundNumber
        {
            get { return _boundNumber; }
            set
            {
                if (_boundNumber != value)
                {
                    _boundNumber = value;
                    OnPropertyChanged();
                }
            }
        }
        



        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }   
}
